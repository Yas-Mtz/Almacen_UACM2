from .models import Solicitud, Almacen, Producto, Persona
from .models import Solicitud
from .models import Solicitud, Producto, Persona
from django import forms
from django.core.exceptions import ValidationError  # Validación correo
from .models import Solicitud, Producto, Persona, Almacen


class RegistroPersonaForm(forms.Form):
    id_rol = forms.CharField(max_length=255)
    nombre = forms.CharField(max_length=255)
    apellido_paterno = forms.CharField(max_length=255)
    apellido_materno = forms.CharField(max_length=255)
    telefono = forms.CharField(max_length=15)
    correo = forms.EmailField()
    contrasena = forms.CharField(max_length=255, widget=forms.PasswordInput())

# Dominios de la UACM
    def clean_correo(self):
        correo = self.cleaned_data.get('correo')
        # Validar el dominio del correo electrónico
        if not correo.endswith('@uacm.edu.mx'):
            raise ValidationError(
                'El correo electrónico debe pertenecer al dominio uacm.edu.mx')
        return correo

#########################


# forms.py


class SolicitudForm(forms.Form):
    tipo_almacen = forms.CharField(
        label='Tipo de Almacen', widget=forms.TextInput(attrs={'readonly': 'readonly'}))
    nombre_persona = forms.CharField(label='Nombre de Persona', required=True)
    nombre_producto = forms.CharField(
        label='Nombre del Producto', required=True)
    cantidad = forms.IntegerField(min_value=1, label='Cantidad')
# clase para enviar correos


class SolicitudAlmacenCentralForm(forms.Form):
    destinatario = forms.EmailField(label='Destinatario', required=True, widget=forms.EmailInput(
        attrs={'id': 'destinatario', 'class': 'form-control'}))
    asunto = forms.CharField(label='Asunto', max_length=255, required=True, widget=forms.TextInput(
        attrs={'id': 'asunto', 'class': 'form-control'}))
    mensaje = forms.CharField(label='Mensaje', widget=forms.Textarea(
        attrs={'id': 'mensaje', 'class': 'form-control', 'rows': 5}), required=True)
    enviar_correo = forms.BooleanField(
        widget=forms.HiddenInput(), initial=True)

    # Agrega más campos según tus necesidades
