document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('form').addEventListener('submit', function(event) {
      event.preventDefault(); // Evitar que el formulario se envíe
  
      // Obtener los valores de los campos del formulario
      var tipoAlmacen = document.getElementById('id_tipo_almacen').value;
      var nombreProducto = document.getElementById('id_nombre_producto').value;
      var cantidad = document.getElementById('id_cantidad').value;
  
      // Crear un elemento para mostrar la información del producto agregado
      var productoAgregado = document.createElement('p');
      productoAgregado.textContent = 'Tipo de Almacén: ' + tipoAlmacen + ', Nombre del Producto: ' + nombreProducto + ', Cantidad: ' + cantidad;
  
      // Agregar el elemento al contenedor de productos agregados
      document.getElementById('productos-agregados').appendChild(productoAgregado);
    });
  });
  