from django.urls import path
from . import views


urlpatterns = [
    # Redirige la raíz a la vista de inicio de sesión
    path('', views.login_view, name='login'),
    path('welcome/', views.welcome_view, name='welcome'),
    path('registrar_persona_prototipo/', views.registrar_persona_prototipo,
         name='registrar_persona_prototipo'),  # urls agregadas

    path('welcome/solicitud_producto/',
         views.solicitud_producto, name='solicitud_producto'),



    # path('guardar_solicitud/', views.guardar_solicitud, name='guardar_solicitud'),

    path('generar_reportes/', views.generar_reportes_view, name='generar_reportes'),
    path('registrar_productos/', views.registrar_productos,
         name='registrar_productos'),
    path('generar-reporte-doc/', views.generar_reporte_doc,
         name='generar_reporte_doc'),
]
