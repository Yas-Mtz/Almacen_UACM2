# Proyecto Escolar 📓
El objetivo de este proyecto, que estamos realizando junto con un equipo de compañeros, es crear una aplicación web para el almacén de nuestra institución educativa. Con el fin de que este proyecto, ayude a que el almacén universitario tenga un mejor control en sus apartados administrativos.

## Diseño 💻
Este proyecto se esta realizando con la ayuda de varias herramientas, entre las que se encuentran:

- Django
- HTML
- JavaScript
- MySQL
- CSS

