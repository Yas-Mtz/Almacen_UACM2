import json
from django.db import connection
from django.http import JsonResponse
from django.shortcuts import render

def generar_reporte_productos(request):
    if request.method == 'POST':
        fecha_inicio = request.POST.get('fecha_inicio')
        fecha_fin = request.POST.get('fecha_fin')

        with connection.cursor() as cursor:
            cursor.callproc('GenerarReporteProductos', [fecha_inicio, fecha_fin])
            productos = cursor.fetchall()
            cursor.nextset()
            solicitudes = cursor.fetchall()

        # Convertir los resultados a formato JSON
        productos_json = [{'id_producto': producto[0], 'nombre_producto': producto[1],
                           'cantidad_total': producto[2], 'tipo_almacen': producto[3],
                           'direccion': producto[4], 'correo': producto[5], 'telefono': producto[6]} for producto in productos]

        solicitudes_json = [{'id_solicitud': solicitud[0], 'tipo_almacen': solicitud[1],
                             'nombre_persona': solicitud[2], 'nombre_producto': solicitud[3],
                             'cantidad': solicitud[4], 'fecha_solicitud': solicitud[5]} for solicitud in solicitudes]
       
        # Imprimir los resultados para verificar
        print("Productos obtenidos:")
        for producto in productos:
            print(producto)
        
        print("\nSolicitudes obtenidas:")
        for solicitud in solicitudes:
            print(solicitud)

        # Devolver los datos en formato JSON usando JsonResponse
        data = {'productos': productos_json, 'solicitudes': solicitudes_json}
        return JsonResponse(data)

    return render(request, 'seleccionar_fechas.html')
