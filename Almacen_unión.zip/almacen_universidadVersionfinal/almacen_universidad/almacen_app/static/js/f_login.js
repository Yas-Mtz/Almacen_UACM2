
function clearFields() {
    var usernameInput = document.getElementById('username');
    var passwordInput = document.getElementById('password');

    usernameInput.value = '';
    passwordInput.value = '';
    }